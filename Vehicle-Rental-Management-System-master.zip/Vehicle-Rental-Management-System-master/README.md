
# Vehicle-Rental-Management-System

This is an Application which can be manage vehicle rental process of a vehicle rental company...


### Using Technologies--->

* Java

* JavaFx

* Layered Architecure

* SceneBuilder

* JDBC

* mySql

* Intellij Idea


*These are the option available in this application.*

1. There is a vehicle registration interface which can be Add, Update and delete a vehicle 
1. Also there is a customer interface 
Which can be Add, Update and delete customer also can be check existing customer.
1. There is an option we check the available vehicle after giving the date duration.
This application calculate the payment details such as net total extra charges bill receipts after return in the vehicle

Project UserInterfaces

![a1](https://user-images.githubusercontent.com/46773105/53080139-0626ae00-351e-11e9-82a5-3c16e2569815.png)

![a3](https://user-images.githubusercontent.com/46773105/53080160-12127000-351e-11e9-84d8-7565ae96ba3c.png)

![a7](https://user-images.githubusercontent.com/46773105/53080419-a4b30f00-351e-11e9-8f91-a3a86acbe933.png)

![a4](https://user-images.githubusercontent.com/46773105/53080165-176fba80-351e-11e9-8deb-f888066985ed.png)

![a2](https://user-images.githubusercontent.com/46773105/53080179-1c346e80-351e-11e9-8235-91eacb7c3f6d.png)

![a5](https://user-images.githubusercontent.com/46773105/53080188-20f92280-351e-11e9-90d4-647f93f663ff.png)

![a6](https://user-images.githubusercontent.com/46773105/53080207-25bdd680-351e-11e9-8097-a3cf6cb4ab10.png)
