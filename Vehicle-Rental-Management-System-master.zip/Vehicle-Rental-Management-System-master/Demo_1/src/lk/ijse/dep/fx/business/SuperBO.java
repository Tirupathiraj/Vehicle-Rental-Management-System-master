package lk.ijse.dep.fx.business;

public interface SuperBO {
}
