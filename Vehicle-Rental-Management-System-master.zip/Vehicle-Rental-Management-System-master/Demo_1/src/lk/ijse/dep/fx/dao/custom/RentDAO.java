package lk.ijse.dep.fx.dao.custom;

import lk.ijse.dep.fx.dao.CrudDAO;
import lk.ijse.dep.fx.entity.Rent;
import lk.ijse.dep.fx.entity.RentPK;

public interface RentDAO extends CrudDAO<Rent, RentPK> {
}
