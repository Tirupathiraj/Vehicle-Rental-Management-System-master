package lk.ijse.dep.fx.dao.custom;

import lk.ijse.dep.fx.dao.CrudDAO;
import lk.ijse.dep.fx.entity.Customer;

public interface CustomerDAO extends CrudDAO<Customer,String> {
}
