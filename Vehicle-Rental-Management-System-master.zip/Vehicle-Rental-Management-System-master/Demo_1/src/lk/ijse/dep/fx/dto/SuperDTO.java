package lk.ijse.dep.fx.dto;

public abstract class SuperDTO {
}
