package lk.ijse.dep.fx.dao.custom;

import lk.ijse.dep.fx.dao.CrudDAO;
import lk.ijse.dep.fx.entity.Payment;

public interface PaymentDAO extends CrudDAO<Payment,String> {
}
