package lk.ijse.dep.fx.entity;

public class SuperEntity {
}
