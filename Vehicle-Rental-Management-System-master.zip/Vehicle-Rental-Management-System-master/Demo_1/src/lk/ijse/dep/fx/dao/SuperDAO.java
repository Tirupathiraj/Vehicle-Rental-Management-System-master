package lk.ijse.dep.fx.dao;

public interface SuperDAO {
}
